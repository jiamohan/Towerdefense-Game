#ifndef TURRET_H
#define TURRET_H

#include "defetowerparent.h"

//绿色炮塔类，继承防御塔父类
class Turret : public DefeTowerParent
{
protected:

public:
    Turret(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth = 80, int Fheight = 80);
};

#endif // TURRET_H
